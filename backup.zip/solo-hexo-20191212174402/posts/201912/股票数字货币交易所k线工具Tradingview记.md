title: 股票/数字货币交易所k线工具Tradingview记
date: '2019-12-08 22:35:59'
updated: '2019-12-08 22:36:34'
tags: [交易所前端开发]
permalink: /articles/2019/12/08/1575815759815.html
---
![null](https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1575825857376&di=9828b9ea316b1af77bd577bdc08c112c&imgtype=0&src=http%3A%2F%2Fdynamic-image.yesky.com%2F320x-%2FuploadImages%2F2019%2F066%2F18%2FG824VL957L15.png)
```
 K线数据不要随便乱造（尤其时间）

（很多人第一次接触TV后，不知道怎么开始，第一步找到Datefeed.js 中的getBars(); 研究这个方法，接上你的数据，然后什么都好办了)


（demo 有时会有删减。没有了的话，自行选择合适自己的吧）

资源地址: https://github.com/tradingview/charting-library-examples
文档地址: https://b.aitrade.ga/books/tradingview/index.html

初始化：
 
请务必仔细 了解这6个配置，尤其后面4个，初始的功能、美观 都在靠它。什么格子线、背景色，K线颜色，K线类型，分隔线颜色 等等等等，文档里好好看看 overrides 
（当你实在找不到配置，请检查元素，如果不是canvas画上去的 dom元素，请用css 覆盖吧）

TV的数据格式（getbars()）

（time单位是S，10位数，ms的请除以1000）

历史数据回来，塞给getBars()的第五个参数  (参考详细问题1)
实时数据回来，塞给subscribeBars()的第三个参数  (参考详细问题2)

数据获取部分的逻辑是开发人员根据自己的实际情况写的
只要保证最终包装成tv的数据格式，并调用回调传给tv就行







常见问题
问题1：数据在哪里进行执行生成K线？
Datefeed.js    getBars();
 准确的说，历史数据必须通过这个回调塞给tv 

问题2：怎么更新实时数据



问题3：一般颜色覆盖修改
custom_css_url: "bundles/xxx.css"

问题4：改底色、K线颜色、格子线。。。。===啥的
看文档 “覆盖 ”部分

问题5：成交量怎么添加分割线啊
volume_force_overlay 功能集，停用它。

成交量高度设置 "volumePaneSize": "medium"
large, medium, small, tiny就这四个值


问题6：关闭成交量
如果是针对个别品种的，那么设置has_no_volume : true
如果是全局的
可以试试停用功能集里的create_volume_indicator_by_default

 问题7：为什么会报事件顺序错误，K线图已经显示了。

TV只支持最后一根K线的重汇。对于重汇已经存在的历史K线，则提示错误。
检查数据，这个错误就是后一个时间戳比前一个时间戳提前了，这部分检查就是比较time的大小，没有其它出错的可能。

问题6：怎么修改语言啊
locale: “en”   // zh


问题： 价格精度

最后发现是需要再datafeed里   resolveSymbol方法中设置pricescale均线精度
studis_overrides: {    "moving average.precision" : 8 }

问题三: 创建指标  createStudy()


问题4：自定义 时间分辨率



自定义btn颜色问题，自定义css

问题：如何去掉箭头？
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
}
input[type="number"]{
  -moz-appearance: textfield;
}

问题：请问下K线数据只有一条，显示时会出现那种无限加载的情况，该怎么处理
要判断数据，如果数据和上次一样就设置noData=true


问题： 请问下 这个默认收起来 是哪个属性， 
问题：这行数据，如何默认是收起来的。

"paneProperties.legendProperties.showLegend": false



"left_toolbar": false,
'paneProperties.legendProperties.showStudyTitles': false, 'paneProperties.legendProperties.showStudyArguments': false, 'paneProperties.legendProperties.showStudyValues': false,
（一个个地试吧）

问题: K 线合成（品种信息中intraday_multipliers）


图表需要加载完数据才会走onChartReady；
K线数据不要随便乱造，K线数据不要随便乱造，K线数据不要随便乱造， 重要的事情已经说了三遍，TV 是严谨的，自定义的数据，请严格对待！（尤其时间）

Craink大佬有话说：
你需要确定几件事情 1、数据是否按格式包装 2、数据是否有通过回调正确传递给tv 3、getBars是否有被频繁调用 4、把右上角的状态找到，看看它现在显示什么 5、控制台是否有报错或者警告 因为看不到你数据具体的值 所以数据本身是否有问题，你也需要检查下 如果是自己模拟的数据，那出问题的概率也不小

问题：udf接入数据后图表狂刷是怎么回事，是时间配置有问题吗
历史数据是不是很少? 看下文档  nodata 。这跟tv的X轴时间有关。会不停的请求数据达到K线铺满当前分辨率的画布

问题：点击一段时间后。时间会出from到to出现负数。页面不停的请求history。 这个是什么情况？

没数据了，传no_data, nextTime一般是在节假日用的，这用法不对


全屏


问题：全屏后怎么显示ESC按钮啊。 
.tv-exit-fullscreen-button {
z-index: 16; 
position: fixed; 
top: -1px;
left: 50%; 
opacity: .6; 
background: #fff; 
color: #848487;
    border-radius: 0 0 3px 3px;
    border: 1px solid #c9cbcd;
    font-size: 11px;
    width: 116px;
    font-weight: 700;
    padding: 2px 4px;
    cursor: default;
    margin: 0 0 0 -59px
}
.feature-no-touch .tv-exit-fullscreen-button:hover { opacity: 1}
加到customCss中，1.9的问题

问题：怎么设置透明度啊，这个不管用 
修改透明度，设置颜色时请采用 rgba 格式


问题，怎么看版本？



问题：请问如何禁用k线上双击弹出的设置吗？



问题：隐藏刻度线
'scalesProperties.lineColor' : "#fff" 

问题：图表在手机上自动隐掉logo后的文字链接 功能集【adaptive_logo 】
disabled_features:【widget_logo】  取消logo显示

问题：怎么去掉logo


问题：请问下加载tv时候设置加载背景色在哪调？
css覆盖  .loading-indicator{} .chart-loading-screen{}   

问题：为啥我的柱状图只有一点点啊
 
数据问题, 基本来说是 整体数据加载的最高价、最低价 差距太大或者没差距。压缩了空间。造数据时请选择一个正常范围内的数据范围内 波动。


问：为什么我的不能选分钟线啊 

time_frames 文档了解一下，另外datafeed.js 中检查


问题：overrides里面的背景色更改竟然被disabled_features影响
清除用户设置缓存use_localstorage_for_settings

问题：是否可以不要subscribe订阅这个方法？直接建立websocket连接之后  有数据变化就推送  ？
不可以，请遵守tv的二次开发流程。已经有不少人在用resetData()做实时数据更新了……乱七八糟

问题：history请求时间怎么变成一秒请求一次

问题：切换时间周期的时候怎么把之前的请求去掉
unsubscribeBar()

问题：去除双击最大化
library.xxxxxxx.js里
搜索this._chart.toggleMaximizePane(this)
删掉它，双击就不会最大化了

问题：

还要在配置library_path里引入




（以下内容，只为提示，具体操作 正确与否，自己去验证）




切换 分辨率 同时 改变 K线 类型






udf和jsapi的区别


noData=true加在哪处理无限加载



更新频率



 所有用这个ws demo的，需要了解一件事 这个demo所针对的后台业务模式是“一次将所有历史数据都传给前端”  一旦缩放图表或向前滚动，需要从后端加载更多数据，那么这个demo是无法保证流程完整的 它用一个定时器轮询去缓存里取数据来更新图表，而这个轮询（指的不是datafeed的轮询）是和历史数据请求无关的，实际上是为了实时数据服务的，对于历史数据的请求来说，这个定时器相当于是异步的。 因为这种异步，造成渲染跑在了数据请求的前面，进而造成误设置noData 


完美解决路由切换bug



问：如何设置K线间距（或 放大K线）
"timeScale.barSpacing":50,

那你试试记录自己数据的时间区间，在时间过小的时候设置（可见范围） setVisibleRange(range, callback)


问题：创建了一个指标和设置的按钮，需要实现点击弹出tv的指标设置弹框和设置弹框。这个是调用哪个方法？  this. Widget.onChartReady(() => {
	// createButton...
this. widget.chart().executeActionById('chartProperties')
})
(本人模拟点击事件，onChartReady() 后 延时5s 才能正确弹出。Craink大佬说需要数据加载完成后，请留意数据的加载状态)
1.12下修复这个问题的话，得改变一下流程。。  这个html拉到最底部 在library.xxxxxxx.js的script标签之上加 <script src="bundles/ds-property-pages.1d6127a623f51513ea4f.js"></script> 让这个模块先被加载 然后library.xxxxx.js中搜索n.logNormal("Property pages loaded") 把后面的5e3改成0 也能解决这个问题

寻根问底
不断请求数据问题
一种情况是：请求左侧历史数据 返回的数据的范围，如果左侧少数据，tv不会再次请求，只认为数据本身就没有
Or
左侧数据如果缺少，是一定会再次发起请求的
目的就是为了尽量保证数据完整性  一种情况是：请求右侧历史数据 返回的数据的范围，如果右侧少数据，tv会再次请求，如果一直不给nodata，就会无限循环
Or
检测右侧数据是不合逻辑的。。。
而且代码里用的也是左侧时间和from做比较

2个解决方案
1个是tv请求的范围 一点要给满
不然他认为没给的就是没有
还有1个方法是 修改tv默认的请求范围


```
